# RTRenderer

Build the project for the 32-bit version, either Release or Debug.