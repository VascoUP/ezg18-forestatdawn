#include "IUpdatable.h"

void IUpdatable::SetUp() {}
void IUpdatable::Update() {}